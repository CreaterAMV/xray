/*     */ package pro.mikey.xray.xray;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import com.mojang.blaze3d.vertex.BufferBuilder;
/*     */ import com.mojang.blaze3d.vertex.DefaultVertexFormat;
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import com.mojang.blaze3d.vertex.Tesselator;
/*     */ import com.mojang.blaze3d.vertex.VertexBuffer;
/*     */ import com.mojang.blaze3d.vertex.VertexFormat;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.GameRenderer;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ import net.minecraftforge.client.event.RenderLevelStageEvent;
/*     */ import org.joml.Matrix4f;
/*     */ import org.joml.Matrix4fc;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import pro.mikey.xray.utils.RenderBlockProps;
/*     */ 
/*     */ public class Render {
/*     */   private static VertexBuffer vertexBuffer;
/*     */   
/*     */   public static boolean requestedRefresh = false;
/*     */   
/*     */   static void renderBlocks(RenderLevelStageEvent event) {
/*  17 */     if (vertexBuffer == null || requestedRefresh) {
/*  18 */       requestedRefresh = false;
/*  19 */       vertexBuffer = new VertexBuffer(VertexBuffer.Usage.STATIC);
/*  21 */       Tesselator tessellator = Tesselator.m_85913_();
/*  22 */       BufferBuilder buffer = tessellator.m_85915_();
/*  24 */       float opacity = 1.0F;
/*  26 */       buffer.m_166779_(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.f_85815_);
/*  28 */       Controller.syncRenderList.forEach(blockProps -> {
/*     */             if (blockProps == null)
/*     */               return; 
/*     */             float size = 1.0F;
/*     */             double x = blockProps.getPos().m_123341_();
/*     */             double y = blockProps.getPos().m_123342_();
/*     */             double z = blockProps.getPos().m_123343_();
/*     */             float red = (blockProps.getColor() >> 16 & 0xFF) / 255.0F;
/*     */             float green = (blockProps.getColor() >> 8 & 0xFF) / 255.0F;
/*     */             float blue = (blockProps.getColor() & 0xFF) / 255.0F;
/*     */             buffer.m_5483_(x, y + 1.0D, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y + 1.0D, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y + 1.0D, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y + 1.0D, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y + 1.0D, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y + 1.0D, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y + 1.0D, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y + 1.0D, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y + 1.0D, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x + 1.0D, y + 1.0D, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y + 1.0D, z + 1.0D).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */             buffer.m_5483_(x, y + 1.0D, z).m_85950_(red, green, blue, opacity).m_5752_();
/*     */           });
/*  76 */       vertexBuffer.m_85921_();
/*  77 */       vertexBuffer.m_231221_(buffer.m_231175_());
/*  78 */       VertexBuffer.m_85931_();
/*     */     } 
/*  81 */     if (vertexBuffer != null) {
/*  82 */       Vec3 view = (Minecraft.m_91087_().m_91290_()).f_114358_.m_90583_();
/*  84 */       GL11.glEnable(3042);
/*  85 */       GL11.glBlendFunc(770, 771);
/*  86 */       GL11.glEnable(2848);
/*  87 */       GL11.glDisable(2929);
/*  89 */       RenderSystem.setShader(GameRenderer::m_172811_);
/*  91 */       PoseStack matrix = event.getPoseStack();
/*  92 */       matrix.m_85836_();
/*  93 */       matrix.m_85837_(-view.f_82479_, -view.f_82480_, -view.f_82481_);
/*  95 */       vertexBuffer.m_85921_();
/*  96 */       vertexBuffer.m_253207_(matrix.m_85850_().m_252922_(), new Matrix4f((Matrix4fc)event.getProjectionMatrix()), RenderSystem.getShader());
/*  97 */       VertexBuffer.m_85931_();
/*  98 */       matrix.m_85849_();
/* 100 */       GL11.glEnable(2929);
/* 101 */       GL11.glDisable(3042);
/* 102 */       GL11.glDisable(2848);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\xray\Render.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */