/*    */ package pro.mikey.xray.xray;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.core.BlockPos;
/*    */ import net.minecraft.world.level.block.state.BlockState;
/*    */ import net.minecraftforge.client.event.RenderLevelStageEvent;
/*    */ import net.minecraftforge.event.TickEvent;
/*    */ 
/*    */ public class Events {
/*    */   public static void breakBlock(BlockPos pos, BlockState blockState) {
/* 13 */     RenderEnqueue.checkBlock(pos, blockState, !blockState.m_60795_());
/*    */   }
/*    */   
/*    */   public static void tickEnd(TickEvent.ClientTickEvent event) {
/* 17 */     if (event.phase == TickEvent.Phase.END && (Minecraft.m_91087_()).f_91074_ != null && (Minecraft.m_91087_()).f_91073_ != null)
/* 18 */       Controller.requestBlockFinder(false); 
/*    */   }
/*    */   
/*    */   public static void onWorldRenderLast(RenderLevelStageEvent event) {
/* 23 */     if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_CUTOUT_BLOCKS)
/*    */       return; 
/* 27 */     if (Controller.isXRayActive() && (Minecraft.m_91087_()).f_91074_ != null)
/* 29 */       Render.renderBlocks(event); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\xray\Events.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */