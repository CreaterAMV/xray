/*     */ package pro.mikey.xray.xray;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import net.minecraft.Util;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.util.Mth;
/*     */ import net.minecraft.world.level.ChunkPos;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraft.world.level.block.Blocks;
/*     */ import pro.mikey.xray.Configuration;
/*     */ import pro.mikey.xray.store.BlockStore;
/*     */ import pro.mikey.xray.utils.RenderBlockProps;
/*     */ 
/*     */ public class Controller {
/*     */   private static final int maxStepsToScan = 5;
/*     */   
/*     */   private static boolean isSearching = false;
/*     */   
/*  26 */   public static ArrayList<Block> blackList = new ArrayList<Block>() {
/*     */     
/*     */     };
/*     */   
/*  34 */   private static ChunkPos lastChunkPos = null;
/*     */   
/*  36 */   public static final Set<RenderBlockProps> syncRenderList = Collections.synchronizedSet(new HashSet<>());
/*     */   
/*  42 */   private static BlockStore blockStore = new BlockStore();
/*     */   
/*     */   private static boolean xrayActive = false;
/*     */   
/*  48 */   private static boolean lavaActive = ((Boolean)Configuration.store.lavaActive.get()).booleanValue();
/*     */   
/*     */   public static BlockStore getBlockStore() {
/*  51 */     return blockStore;
/*     */   }
/*     */   
/*     */   public static boolean isXRayActive() {
/*  56 */     return (xrayActive && (Minecraft.m_91087_()).f_91073_ != null && (Minecraft.m_91087_()).f_91074_ != null);
/*     */   }
/*     */   
/*     */   public static void toggleXRay() {
/*  60 */     if (!xrayActive) {
/*  62 */       syncRenderList.clear();
/*  63 */       xrayActive = true;
/*  64 */       requestBlockFinder(true);
/*  66 */       if (!((Boolean)Configuration.general.showOverlay.get()).booleanValue() && (Minecraft.m_91087_()).f_91074_ != null)
/*  67 */         (Minecraft.m_91087_()).f_91074_.m_5661_((Component)Component.m_237115_("xray.toggle.activated"), false); 
/*     */     } else {
/*  70 */       if (!((Boolean)Configuration.general.showOverlay.get()).booleanValue() && (Minecraft.m_91087_()).f_91074_ != null)
/*  71 */         (Minecraft.m_91087_()).f_91074_.m_5661_((Component)Component.m_237115_("xray.toggle.deactivated"), false); 
/*  73 */       xrayActive = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isLavaActive() {
/*  78 */     return lavaActive;
/*     */   }
/*     */   
/*     */   public static void toggleLava() {
/*  82 */     lavaActive = !lavaActive;
/*  83 */     Configuration.store.lavaActive.set(Boolean.valueOf(lavaActive));
/*     */   }
/*     */   
/*     */   public static int getRadius() {
/*  87 */     return Mth.m_14045_(((Integer)Configuration.store.radius.get()).intValue(), 0, 5) * 3;
/*     */   }
/*     */   
/*     */   public static int getHalfRange() {
/*  91 */     return Math.max(0, getRadius() / 2);
/*     */   }
/*     */   
/*     */   public static int getVisualRadius() {
/*  95 */     return Math.max(1, getRadius());
/*     */   }
/*     */   
/*     */   public static void incrementCurrentDist() {
/*  99 */     if (((Integer)Configuration.store.radius.get()).intValue() < 5) {
/* 100 */       Configuration.store.radius.set(Integer.valueOf(((Integer)Configuration.store.radius.get()).intValue() + 1));
/*     */     } else {
/* 102 */       Configuration.store.radius.set(Integer.valueOf(0));
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void decrementCurrentDist() {
/* 106 */     if (((Integer)Configuration.store.radius.get()).intValue() > 0) {
/* 107 */       Configuration.store.radius.set(Integer.valueOf(((Integer)Configuration.store.radius.get()).intValue() - 1));
/*     */     } else {
/* 109 */       Configuration.store.radius.set(Integer.valueOf(5));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean playerHasMoved() {
/* 121 */     if ((Minecraft.m_91087_()).f_91074_ == null)
/* 122 */       return false; 
/* 124 */     ChunkPos plyChunkPos = (Minecraft.m_91087_()).f_91074_.m_146902_();
/* 125 */     int range = getHalfRange();
/* 127 */     return (lastChunkPos == null || plyChunkPos.f_45578_ > lastChunkPos.f_45578_ + range || plyChunkPos.f_45578_ < lastChunkPos.f_45578_ - range || plyChunkPos.f_45579_ > lastChunkPos.f_45579_ + range || plyChunkPos.f_45579_ < lastChunkPos.f_45579_ - range);
/*     */   }
/*     */   
/*     */   private static void updatePlayerPosition() {
/* 133 */     lastChunkPos = (Minecraft.m_91087_()).f_91074_.m_146902_();
/*     */   }
/*     */   
/*     */   public static synchronized void requestBlockFinder(boolean force) {
/* 146 */     if (isXRayActive() && (force || playerHasMoved()) && !isSearching) {
/* 148 */       updatePlayerPosition();
/* 149 */       Util.m_183991_().execute(() -> {
/*     */             isSearching = true;
/*     */             Set<RenderBlockProps> c = RenderEnqueue.blockFinder();
/*     */             syncRenderList.clear();
/*     */             syncRenderList.addAll(c);
/*     */             isSearching = false;
/*     */             Render.requestedRefresh = true;
/*     */           });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\xray\Controller.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */