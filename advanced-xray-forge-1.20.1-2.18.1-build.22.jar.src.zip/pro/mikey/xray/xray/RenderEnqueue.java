/*     */ package pro.mikey.xray.xray;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.multiplayer.ClientLevel;
/*     */ import net.minecraft.client.player.LocalPlayer;
/*     */ import net.minecraft.core.BlockPos;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.level.block.state.BlockState;
/*     */ import net.minecraft.world.level.material.FluidState;
/*     */ import net.minecraft.world.level.material.Fluids;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import org.apache.commons.lang3.tuple.Pair;
/*     */ import pro.mikey.xray.utils.BlockData;
/*     */ import pro.mikey.xray.utils.RenderBlockProps;
/*     */ 
/*     */ public class RenderEnqueue {
/*     */   public static Set<RenderBlockProps> blockFinder() {
/*  24 */     HashMap<UUID, BlockData> blocks = Controller.getBlockStore().getStore();
/*  25 */     if (blocks.isEmpty())
/*  26 */       return new HashSet<>(); 
/*  29 */     ClientLevel clientLevel = (Minecraft.m_91087_()).f_91073_;
/*  30 */     LocalPlayer localPlayer = (Minecraft.m_91087_()).f_91074_;
/*  33 */     if (clientLevel == null || localPlayer == null)
/*  34 */       return new HashSet<>(); 
/*  37 */     Set<RenderBlockProps> renderQueue = new HashSet<>();
/*  39 */     int range = Controller.getHalfRange();
/*  41 */     int cX = (localPlayer.m_146902_()).f_45578_;
/*  42 */     int cZ = (localPlayer.m_146902_()).f_45579_;
/*  50 */     for (int i = cX - range; i <= cX + range; i++) {
/*  51 */       int chunkStartX = i << 4;
/*  52 */       for (int j = cZ - range; j <= cZ + range; j++) {
/*  53 */         int chunkStartZ = j << 4;
/*  55 */         for (int k = chunkStartX; k < chunkStartX + 16; k++) {
/*  56 */           for (int l = chunkStartZ; l < chunkStartZ + 16; l++) {
/*  57 */             for (int m = clientLevel.m_141937_(); m < clientLevel.m_151558_(); m++) {
/*  58 */               BlockPos pos = new BlockPos(k, m, l);
/*  60 */               BlockState currentState = clientLevel.m_8055_(pos);
/*  61 */               FluidState currentFluid = currentState.m_60819_();
/*  63 */               if ((currentFluid.m_76152_() == Fluids.f_76195_ || currentFluid.m_76152_() == Fluids.f_76194_) && Controller.isLavaActive()) {
/*  64 */                 renderQueue.add(new RenderBlockProps(pos.m_123341_(), pos.m_123342_(), pos.m_123343_(), 16711680));
/*  69 */               } else if (!Controller.blackList.contains(currentState.m_60734_())) {
/*  72 */                 ResourceLocation block = ForgeRegistries.BLOCKS.getKey(currentState.m_60734_());
/*  73 */                 if (block != null) {
/*  76 */                   Pair<BlockData, UUID> dataWithUUID = Controller.getBlockStore().getStoreByReference(block.toString());
/*  77 */                   if (dataWithUUID != null)
/*  80 */                     if (dataWithUUID.getKey() != null && ((BlockData)dataWithUUID.getKey()).isDrawing())
/*  84 */                       renderQueue.add(new RenderBlockProps(pos.m_123341_(), pos.m_123342_(), pos.m_123343_(), ((BlockData)dataWithUUID.getKey()).getColor()));  
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  91 */     return renderQueue;
/*     */   }
/*     */   
/*     */   public static void checkBlock(BlockPos pos, BlockState state, boolean add) {
/* 103 */     if (!Controller.isXRayActive() || Controller.getBlockStore().getStore().isEmpty())
/*     */       return; 
/* 107 */     if (!add) {
/* 108 */       boolean removed = Controller.syncRenderList.remove(new RenderBlockProps(pos, 0));
/* 109 */       if (removed)
/* 110 */         Render.requestedRefresh = true; 
/*     */       return;
/*     */     } 
/* 115 */     ResourceLocation block = ForgeRegistries.BLOCKS.getKey(state.m_60734_());
/* 116 */     if (block == null)
/*     */       return; 
/* 119 */     Pair<BlockData, UUID> dataWithUUID = Controller.getBlockStore().getStoreByReference(block.toString());
/* 120 */     if (dataWithUUID == null || dataWithUUID.getKey() == null || !((BlockData)dataWithUUID.getKey()).isDrawing())
/*     */       return; 
/* 124 */     Controller.syncRenderList.add(new RenderBlockProps(pos, ((BlockData)dataWithUUID.getKey()).getColor()));
/* 125 */     Render.requestedRefresh = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\xray\RenderEnqueue.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */