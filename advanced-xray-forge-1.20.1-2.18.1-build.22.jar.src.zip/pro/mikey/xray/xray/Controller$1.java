/*    */ package pro.mikey.xray.xray;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.world.level.block.Block;
/*    */ import net.minecraft.world.level.block.Blocks;
/*    */ 
/*    */ class null extends ArrayList<Block> {
/*    */   null() {
/* 27 */     add(Blocks.f_50016_);
/* 28 */     add(Blocks.f_50752_);
/* 29 */     add(Blocks.f_50069_);
/* 30 */     add(Blocks.f_50034_);
/* 31 */     add(Blocks.f_50493_);
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\xray\Controller$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */