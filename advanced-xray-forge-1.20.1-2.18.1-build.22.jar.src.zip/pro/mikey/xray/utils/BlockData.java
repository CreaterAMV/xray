/*    */ package pro.mikey.xray.utils;
/*    */ 
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ 
/*    */ public class BlockData {
/*    */   private String entryName;
/*    */   
/*    */   private String blockName;
/*    */   
/*    */   private int color;
/*    */   
/*    */   private ItemStack itemStack;
/*    */   
/*    */   private boolean drawing;
/*    */   
/*    */   private int order;
/*    */   
/*    */   public BlockData(String entryName, String blockName, int color, ItemStack itemStack, boolean drawing, int order) {
/* 17 */     this.entryName = entryName;
/* 18 */     this.blockName = blockName;
/* 19 */     this.color = color;
/* 20 */     this.itemStack = itemStack;
/* 21 */     this.drawing = drawing;
/* 22 */     this.order = order;
/*    */   }
/*    */   
/*    */   public String getEntryName() {
/* 26 */     return this.entryName;
/*    */   }
/*    */   
/*    */   public String getBlockName() {
/* 30 */     return this.blockName;
/*    */   }
/*    */   
/*    */   public int getColor() {
/* 34 */     return this.color;
/*    */   }
/*    */   
/*    */   public ItemStack getItemStack() {
/* 38 */     return this.itemStack;
/*    */   }
/*    */   
/*    */   public boolean isDrawing() {
/* 42 */     return this.drawing;
/*    */   }
/*    */   
/*    */   public void setDrawing(boolean drawing) {
/* 46 */     this.drawing = drawing;
/*    */   }
/*    */   
/*    */   public void setColor(int color) {
/* 50 */     this.color = color;
/*    */   }
/*    */   
/*    */   public int getOrder() {
/* 54 */     return this.order;
/*    */   }
/*    */   
/*    */   public static class SerializableBlockData {
/*    */     private String name;
/*    */     
/*    */     private String blockName;
/*    */     
/*    */     private int order;
/*    */     
/*    */     private int color;
/*    */     
/*    */     private boolean drawing;
/*    */     
/*    */     public SerializableBlockData(String name, String blockName, int color, boolean drawing, int order) {
/* 68 */       this.name = name;
/* 69 */       this.blockName = blockName;
/* 70 */       this.color = color;
/* 71 */       this.drawing = drawing;
/* 72 */       this.order = order;
/*    */     }
/*    */     
/*    */     public String getName() {
/* 76 */       return this.name;
/*    */     }
/*    */     
/*    */     public String getBlockName() {
/* 80 */       return this.blockName;
/*    */     }
/*    */     
/*    */     public int getColor() {
/* 84 */       return this.color;
/*    */     }
/*    */     
/*    */     public boolean isDrawing() {
/* 88 */       return this.drawing;
/*    */     }
/*    */     
/*    */     public int getOrder() {
/* 92 */       return this.order;
/*    */     }
/*    */     
/*    */     public void setOrder(int order) {
/* 96 */       this.order = order;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xra\\utils\BlockData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */