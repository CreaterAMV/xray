/*    */ package pro.mikey.xray.utils;
/*    */ 
/*    */ import com.google.common.base.Objects;
/*    */ import javax.annotation.concurrent.Immutable;
/*    */ import net.minecraft.core.BlockPos;
/*    */ 
/*    */ @Immutable
/*    */ public class RenderBlockProps {
/*    */   private final int color;
/*    */   
/*    */   private final BlockPos pos;
/*    */   
/*    */   public RenderBlockProps(BlockPos pos, int color) {
/* 14 */     this.pos = pos;
/* 15 */     this.color = color;
/*    */   }
/*    */   
/*    */   public RenderBlockProps(int x, int y, int z, int color) {
/* 19 */     this(new BlockPos(x, y, z), color);
/*    */   }
/*    */   
/*    */   public int getColor() {
/* 23 */     return this.color;
/*    */   }
/*    */   
/*    */   public BlockPos getPos() {
/* 27 */     return this.pos;
/*    */   }
/*    */   
/*    */   public boolean equals(Object o) {
/* 32 */     if (this == o)
/* 32 */       return true; 
/* 33 */     if (o == null || getClass() != o.getClass())
/* 33 */       return false; 
/* 34 */     RenderBlockProps that = (RenderBlockProps)o;
/* 35 */     return Objects.equal(this.pos, that.pos);
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 40 */     return Objects.hashCode(new Object[] { this.pos });
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xra\\utils\RenderBlockProps.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */