/*    */ package pro.mikey.xray.utils;
/*    */ 
/*    */ public class SerializableBlockData {
/*    */   private String name;
/*    */   
/*    */   private String blockName;
/*    */   
/*    */   private int order;
/*    */   
/*    */   private int color;
/*    */   
/*    */   private boolean drawing;
/*    */   
/*    */   public SerializableBlockData(String name, String blockName, int color, boolean drawing, int order) {
/* 68 */     this.name = name;
/* 69 */     this.blockName = blockName;
/* 70 */     this.color = color;
/* 71 */     this.drawing = drawing;
/* 72 */     this.order = order;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 76 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getBlockName() {
/* 80 */     return this.blockName;
/*    */   }
/*    */   
/*    */   public int getColor() {
/* 84 */     return this.color;
/*    */   }
/*    */   
/*    */   public boolean isDrawing() {
/* 88 */     return this.drawing;
/*    */   }
/*    */   
/*    */   public int getOrder() {
/* 92 */     return this.order;
/*    */   }
/*    */   
/*    */   public void setOrder(int order) {
/* 96 */     this.order = order;
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xra\\utils\BlockData$SerializableBlockData.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */