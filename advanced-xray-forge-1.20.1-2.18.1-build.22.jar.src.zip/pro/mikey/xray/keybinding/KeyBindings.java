/*    */ package pro.mikey.xray.keybinding;
/*    */ 
/*    */ import net.minecraft.client.KeyMapping;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.client.resources.language.I18n;
/*    */ import net.minecraftforge.client.event.InputEvent;
/*    */ import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import pro.mikey.xray.gui.GuiSelectionScreen;
/*    */ import pro.mikey.xray.xray.Controller;
/*    */ 
/*    */ public class KeyBindings {
/*    */   private static final String CATEGORY = "X-Ray";
/*    */   
/* 17 */   public static KeyMapping toggleXRay = new KeyMapping(I18n.m_118938_("xray.config.toggle", new Object[0]), 92, "X-Ray");
/*    */   
/* 18 */   public static KeyMapping toggleGui = new KeyMapping(I18n.m_118938_("xray.config.open", new Object[0]), 71, "X-Ray");
/*    */   
/*    */   public static void setup() {}
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void registerKeyBinding(RegisterKeyMappingsEvent event) {
/* 25 */     event.register(toggleXRay);
/* 26 */     event.register(toggleGui);
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public static void eventInput(InputEvent event) {
/* 31 */     Minecraft mc = Minecraft.m_91087_();
/* 32 */     if (mc.f_91074_ == null || (Minecraft.m_91087_()).f_91080_ != null || (Minecraft.m_91087_()).f_91073_ == null)
/*    */       return; 
/* 35 */     if (toggleXRay.m_90859_())
/* 36 */       Controller.toggleXRay(); 
/* 39 */     if (toggleGui.m_90859_())
/* 40 */       Minecraft.m_91087_().m_91152_((Screen)new GuiSelectionScreen()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\keybinding\KeyBindings.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */