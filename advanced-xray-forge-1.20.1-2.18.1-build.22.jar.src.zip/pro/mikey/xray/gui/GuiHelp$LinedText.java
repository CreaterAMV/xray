/*    */ package pro.mikey.xray.gui;
/*    */ 
/*    */ import net.minecraft.client.resources.language.I18n;
/*    */ 
/*    */ class LinedText {
/*    */   private String[] lines;
/*    */   
/*    */   LinedText(String key) {
/* 73 */     this.lines = I18n.m_118938_(key, new Object[0]).split("\\R");
/*    */   }
/*    */   
/*    */   String[] getLines() {
/* 77 */     return this.lines;
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\GuiHelp$LinedText.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */