/*    */ package pro.mikey.xray.gui;
/*    */ 
/*    */ import com.mojang.blaze3d.systems.RenderSystem;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.resources.language.I18n;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import net.minecraftforge.api.distmarker.Dist;
/*    */ import net.minecraftforge.api.distmarker.OnlyIn;
/*    */ import net.minecraftforge.client.event.RenderGuiOverlayEvent;
/*    */ import net.minecraftforge.eventbus.api.EventPriority;
/*    */ import net.minecraftforge.eventbus.api.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
/*    */ import pro.mikey.xray.Configuration;
/*    */ import pro.mikey.xray.XRay;
/*    */ import pro.mikey.xray.xray.Controller;
/*    */ 
/*    */ @EventBusSubscriber(modid = "xray", value = {Dist.CLIENT})
/*    */ public class GuiOverlay {
/* 20 */   private static final ResourceLocation CIRCLE = new ResourceLocation(XRay.PREFIX_GUI + "circle.png");
/*    */   
/*    */   @OnlyIn(Dist.CLIENT)
/*    */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*    */   public static void RenderGameOverlayEvent(RenderGuiOverlayEvent event) {
/* 26 */     if (!Controller.isXRayActive() || !((Boolean)Configuration.general.showOverlay.get()).booleanValue() || event.isCanceled())
/*    */       return; 
/* 29 */     RenderSystem.setShaderColor(0.0F, 1.0F, 0.0F, 1.0F);
/* 30 */     RenderSystem.setShaderTexture(0, CIRCLE);
/* 31 */     GuiGraphics guiGraphics = event.getGuiGraphics();
/* 32 */     guiGraphics.m_280163_(CIRCLE, 5, 5, 0.0F, 0.0F, 5, 5, 5, 5);
/* 34 */     guiGraphics.m_280488_((Minecraft.m_91087_()).f_91062_, I18n.m_118938_("xray.overlay", new Object[0]), 15, 4, -1);
/* 37 */     RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\GuiOverlay.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */