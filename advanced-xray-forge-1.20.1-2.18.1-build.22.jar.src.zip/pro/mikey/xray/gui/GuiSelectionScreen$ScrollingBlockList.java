/*     */ package pro.mikey.xray.gui;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.locale.Language;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import pro.mikey.xray.ClientController;
/*     */ import pro.mikey.xray.gui.manage.GuiEdit;
/*     */ import pro.mikey.xray.gui.utils.ScrollingList;
/*     */ import pro.mikey.xray.utils.BlockData;
/*     */ import pro.mikey.xray.xray.Controller;
/*     */ 
/*     */ class ScrollingBlockList extends ScrollingList<GuiSelectionScreen.ScrollingBlockList.BlockSlot> {
/*     */   static final int SLOT_HEIGHT = 35;
/*     */   
/*     */   public GuiSelectionScreen parent;
/*     */   
/*     */   ScrollingBlockList(int x, int y, int width, int height, List<BlockData> blocks, GuiSelectionScreen parent) {
/* 258 */     super(x, y, width, height, 35);
/* 259 */     updateEntries(blocks);
/* 260 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   public void setSelected(@Nullable BlockSlot entry, int mouse) {
/* 264 */     if (entry == null)
/*     */       return; 
/* 267 */     if (GuiSelectionScreen.m_96638_()) {
/* 268 */       (Minecraft.m_91087_()).f_91074_.m_6915_();
/* 269 */       Minecraft.m_91087_().m_91152_((Screen)new GuiEdit(entry.block));
/*     */       return;
/*     */     } 
/* 273 */     Controller.getBlockStore().toggleDrawing(entry.block);
/* 274 */     ClientController.blockStore.write(new ArrayList(Controller.getBlockStore().getStore().values()));
/*     */   }
/*     */   
/*     */   void updateEntries(List<BlockData> blocks) {
/* 278 */     m_93516_();
/* 279 */     blocks.forEach(block -> m_7085_(new BlockSlot(block, this)));
/*     */   }
/*     */   
/*     */   public static class BlockSlot extends AbstractSelectionList.Entry<BlockSlot> {
/*     */     BlockData block;
/*     */     
/*     */     GuiSelectionScreen.ScrollingBlockList parent;
/*     */     
/*     */     BlockSlot(BlockData block, GuiSelectionScreen.ScrollingBlockList parent) {
/* 287 */       this.block = block;
/* 288 */       this.parent = parent;
/*     */     }
/*     */     
/*     */     public BlockData getBlock() {
/* 292 */       return this.block;
/*     */     }
/*     */     
/*     */     public void m_6311_(GuiGraphics guiGraphics, int entryIdx, int top, int left, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean p_194999_5_, float partialTicks) {
/* 297 */       BlockData blockData = this.block;
/* 299 */       Font font = (Minecraft.m_91087_()).f_91062_;
/* 301 */       guiGraphics.m_280488_(font, blockData.getEntryName(), left + 35, top + 7, 16777215);
/* 302 */       guiGraphics.m_280488_(font, blockData.isDrawing() ? "Enabled" : "Disabled", left + 35, top + 17, blockData.isDrawing() ? Color.GREEN.getRGB() : Color.RED.getRGB());
/* 304 */       guiGraphics.m_280480_(blockData.getItemStack(), left + 8, top + 7);
/* 305 */       guiGraphics.m_280370_(font, blockData.getItemStack(), left + 8, top + 7);
/* 312 */       if (mouseX > left && mouseX < left + entryWidth && mouseY > top && mouseY < top + entryHeight && mouseY < this.parent.getTop() + this.parent.getHeight() && mouseY > this.parent.getTop())
/* 313 */         guiGraphics.m_280245_(font, 
/*     */             
/* 315 */             Language.m_128107_().m_128112_(Arrays.asList(new FormattedText[] { (FormattedText)Component.m_237115_("xray.tooltips.edit1"), (FormattedText)Component.m_237115_("xray.tooltips.edit2") }, )), left + 15, 
/*     */             
/* 317 */             (entryIdx == this.parent.m_6702_().size() - 1) ? (top - entryHeight - 20) : (top + entryHeight + 15)); 
/* 321 */       Color color = new Color(blockData.getColor());
/* 323 */       PoseStack stack = guiGraphics.m_280168_();
/* 324 */       stack.m_85836_();
/* 325 */       RenderSystem.enableBlend();
/* 326 */       RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/* 328 */       RenderSystem.setShaderColor(0.0F, 0.0F, 0.0F, 0.5F);
/* 329 */       guiGraphics.m_280163_(GuiSelectionScreen.CIRCLE, left + entryWidth - 35, (int)(top + entryHeight / 2.0F - 9.0F), 0.0F, 0.0F, 14, 14, 14, 14);
/* 330 */       RenderSystem.setShaderColor(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, 1.0F);
/* 331 */       guiGraphics.m_280163_(GuiSelectionScreen.CIRCLE, left + entryWidth - 33, (int)(top + entryHeight / 2.0F - 7.0F), 0.0F, 0.0F, 10, 10, 10, 10);
/* 332 */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 333 */       RenderSystem.disableBlend();
/* 334 */       stack.m_85849_();
/*     */     }
/*     */     
/*     */     public boolean m_6375_(double p_mouseClicked_1_, double p_mouseClicked_3_, int mouse) {
/* 339 */       this.parent.setSelected(this, mouse);
/* 340 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\GuiSelectionScreen$ScrollingBlockList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */