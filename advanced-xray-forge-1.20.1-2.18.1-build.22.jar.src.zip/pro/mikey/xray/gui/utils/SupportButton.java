/*    */ package pro.mikey.xray.gui.utils;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.network.chat.FormattedText;
/*    */ import net.minecraft.network.chat.MutableComponent;
/*    */ 
/*    */ public class SupportButton extends Button {
/* 13 */   private List<FormattedText> support = new ArrayList<>();
/*    */   
/*    */   public SupportButton(int widthIn, int heightIn, int width, int height, Component text, MutableComponent support, Button.OnPress onPress) {
/* 16 */     super(m_253074_(text, onPress)
/* 17 */         .m_252794_(widthIn, heightIn)
/* 18 */         .m_253046_(width, height));
/* 20 */     for (String line : support.getString().split("\n"))
/* 21 */       this.support.add(Component.m_237113_(line)); 
/*    */   }
/*    */   
/*    */   public List<FormattedText> getSupport() {
/* 26 */     return this.support;
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gu\\utils\SupportButton.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */