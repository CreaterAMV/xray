/*    */ package pro.mikey.xray.gui.utils;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*    */ import net.minecraft.client.gui.narration.NarrationElementOutput;
/*    */ import org.lwjgl.opengl.GL11;
/*    */ 
/*    */ public class ScrollingList<E extends AbstractSelectionList.Entry<E>> extends AbstractSelectionList<E> {
/*    */   public ScrollingList(int x, int y, int width, int height, int slotHeightIn) {
/* 20 */     super(Minecraft.m_91087_(), width, height, y - height / 2, y - height / 2 + height, slotHeightIn);
/* 21 */     m_93507_(x - width / 2);
/* 22 */     m_93488_(false);
/* 23 */     m_93496_(false);
/*    */   }
/*    */   
/*    */   public void m_88315_(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
/* 28 */     double scale = Minecraft.m_91087_().m_91268_().m_85449_();
/* 30 */     GL11.glEnable(3089);
/* 31 */     GL11.glScissor((int)(this.f_93393_ * scale), (int)(Minecraft.m_91087_().m_91268_().m_85442_() - (this.f_93390_ + this.f_93389_) * scale), (int)(this.f_93388_ * scale), (int)(this.f_93389_ * scale));
/* 34 */     super.m_88315_(guiGraphics, mouseX, mouseY, partialTicks);
/* 36 */     GL11.glDisable(3089);
/*    */   }
/*    */   
/*    */   protected int m_5756_() {
/* 41 */     return this.f_93393_ + this.f_93388_ - 6;
/*    */   }
/*    */   
/*    */   public void m_142291_(NarrationElementOutput p_169152_) {}
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gu\\utils\ScrollingList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */