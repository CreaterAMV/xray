/*     */ package pro.mikey.xray.gui.utils;
/*     */ 
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.locale.Language;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import pro.mikey.xray.XRay;
/*     */ 
/*     */ public abstract class GuiBase extends Screen {
/*  15 */   public static final ResourceLocation BG_NORMAL = new ResourceLocation(XRay.PREFIX_GUI + "bg.png");
/*     */   
/*  16 */   public static final ResourceLocation BG_LARGE = new ResourceLocation(XRay.PREFIX_GUI + "bg-help.png");
/*     */   
/*     */   private boolean hasSide;
/*     */   
/*  19 */   private String sideTitle = "";
/*     */   
/*  20 */   private int backgroundWidth = 229;
/*     */   
/*  21 */   private int backgroundHeight = 235;
/*     */   
/*     */   public GuiBase(boolean hasSide) {
/*  24 */     super((Component)Component.m_237113_(""));
/*  25 */     this.hasSide = hasSide;
/*     */   }
/*     */   
/*     */   public abstract void renderExtra(GuiGraphics paramGuiGraphics, int paramInt1, int paramInt2, float paramFloat);
/*     */   
/*     */   public boolean m_5534_(char keyTyped, int __unknown) {
/*  32 */     super.m_5534_(keyTyped, __unknown);
/*  34 */     if (keyTyped == '\001' && (getMinecraft()).f_91074_ != null)
/*  35 */       (getMinecraft()).f_91074_.m_6915_(); 
/*  37 */     return false;
/*     */   }
/*     */   
/*     */   public void m_88315_(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
/*  42 */     m_280273_(guiGraphics);
/*  44 */     int width = this.f_96543_;
/*  45 */     int height = this.f_96544_;
/*  46 */     if (this.hasSide) {
/*  47 */       guiGraphics.m_280163_(getBackground(), width / 2 + 60, height / 2 - 90, 0.0F, 0.0F, 150, 180, 150, 180);
/*  48 */       guiGraphics.m_280163_(getBackground(), width / 2 - 150, height / 2 - 118, 0.0F, 0.0F, this.backgroundWidth, this.backgroundHeight, this.backgroundWidth, this.backgroundHeight);
/*  50 */       if (hasSideTitle())
/*  51 */         guiGraphics.m_280488_(getFontRender(), this.sideTitle, width / 2 + 80, height / 2 - 77, 16776960); 
/*     */     } 
/*  54 */     if (!this.hasSide)
/*  55 */       guiGraphics.m_280163_(getBackground(), width / 2 - this.backgroundWidth / 2 + 1, height / 2 - this.backgroundHeight / 2, 0.0F, 0.0F, this.backgroundWidth, this.backgroundHeight, this.backgroundWidth, this.backgroundHeight); 
/*  58 */     if (hasTitle())
/*  59 */       if (this.hasSide) {
/*  60 */         guiGraphics.m_280488_(getFontRender(), title(), width / 2 - 138, height / 2 - 105, 16776960);
/*     */       } else {
/*  62 */         guiGraphics.m_280488_(getFontRender(), title(), width / 2 - this.backgroundWidth / 2 + 14, height / 2 - this.backgroundHeight / 2 + 13, 16776960);
/*     */       }  
/*  65 */     super.m_88315_(guiGraphics, x, y, partialTicks);
/*  66 */     renderExtra(guiGraphics, x, y, partialTicks);
/*  68 */     for (GuiEventListener button : m_6702_()) {
/*  69 */       if (button instanceof SupportButton && ((SupportButton)button).m_198029_())
/*  70 */         guiGraphics.m_280245_(getFontRender(), Language.m_128107_().m_128112_(((SupportButton)button).getSupport()), x, y); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public ResourceLocation getBackground() {
/*  75 */     return BG_NORMAL;
/*     */   }
/*     */   
/*     */   public boolean hasTitle() {
/*  79 */     return false;
/*     */   }
/*     */   
/*     */   public String title() {
/*  83 */     return "";
/*     */   }
/*     */   
/*     */   private boolean hasSideTitle() {
/*  87 */     return !this.sideTitle.isEmpty();
/*     */   }
/*     */   
/*     */   protected void setSideTitle(String title) {
/*  91 */     this.sideTitle = title;
/*     */   }
/*     */   
/*     */   public void setSize(int width, int height) {
/*  95 */     this.backgroundWidth = width;
/*  96 */     this.backgroundHeight = height;
/*     */   }
/*     */   
/*     */   public Font getFontRender() {
/* 100 */     return (getMinecraft()).f_91062_;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 104 */     return this.f_96543_;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 108 */     return this.f_96544_;
/*     */   }
/*     */   
/*     */   public boolean m_7043_() {
/* 113 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gu\\utils\GuiBase.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */