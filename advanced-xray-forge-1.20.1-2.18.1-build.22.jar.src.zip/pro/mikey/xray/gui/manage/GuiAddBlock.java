/*     */ package pro.mikey.xray.gui.manage;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.EditBox;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.resources.language.I18n;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.ItemLike;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraftforge.client.gui.widget.ForgeSlider;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import pro.mikey.xray.ClientController;
/*     */ import pro.mikey.xray.gui.GuiSelectionScreen;
/*     */ import pro.mikey.xray.gui.utils.GuiBase;
/*     */ import pro.mikey.xray.utils.BlockData;
/*     */ import pro.mikey.xray.xray.Controller;
/*     */ 
/*     */ public class GuiAddBlock extends GuiBase {
/*     */   private EditBox oreName;
/*     */   
/*     */   private ForgeSlider redSlider;
/*     */   
/*     */   private ForgeSlider greenSlider;
/*     */   
/*     */   private ForgeSlider blueSlider;
/*     */   
/*     */   private final Block selectBlock;
/*     */   
/*     */   private final ItemStack itemStack;
/*     */   
/*     */   private boolean oreNameCleared = false;
/*     */   
/*     */   private final Supplier<GuiBase> previousScreenCallback;
/*     */   
/*     */   public GuiAddBlock(Block selectedBlock, Supplier<GuiBase> previousScreenCallback) {
/*  40 */     super(false);
/*  41 */     this.selectBlock = selectedBlock;
/*  42 */     this.previousScreenCallback = previousScreenCallback;
/*  43 */     this.itemStack = new ItemStack((ItemLike)this.selectBlock, 1);
/*     */   }
/*     */   
/*     */   public void m_7856_() {
/*  49 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237115_("xray.single.add"), b -> {
/*     */             m_7379_();
/*     */             ResourceLocation key = ForgeRegistries.BLOCKS.getKey(this.selectBlock);
/*     */             if (key == null)
/*     */               return; 
/*     */             Controller.getBlockStore().put(new BlockData(this.oreName.m_94155_(), key.toString(), ((int)this.redSlider.getValue() << 16) + ((int)this.greenSlider.getValue() << 8) + (int)this.blueSlider.getValue(), this.itemStack, true, Controller.getBlockStore().getStore().size() + 1));
/*     */             ClientController.blockStore.write(new ArrayList(Controller.getBlockStore().getStore().values()));
/*     */             getMinecraft().m_91152_((Screen)new GuiSelectionScreen());
/*  71 */           }).m_252794_(getWidth() / 2 - 100, getHeight() / 2 + 85)
/*  72 */         .m_253046_(128, 20)
/*  73 */         .m_253136_());
/*  75 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237115_("xray.single.cancel"), b -> {
/*     */             m_7379_();
/*     */             Minecraft.m_91087_().m_91152_((Screen)this.previousScreenCallback.get());
/*  79 */           }).m_252794_(getWidth() / 2 + 30, getHeight() / 2 + 85)
/*  80 */         .m_253046_(72, 20)
/*  81 */         .m_253136_());
/*  83 */     m_142416_((GuiEventListener)(this.redSlider = new ForgeSlider(getWidth() / 2 - 100, getHeight() / 2 + 7, 202, 20, (Component)Component.m_237115_("xray.color.red"), (Component)Component.m_237119_(), 0.0D, 255.0D, 0.0D, true)));
/*  84 */     m_142416_((GuiEventListener)(this.greenSlider = new ForgeSlider(getWidth() / 2 - 100, getHeight() / 2 + 30, 202, 20, (Component)Component.m_237115_("xray.color.green"), (Component)Component.m_237119_(), 0.0D, 255.0D, 165.0D, true)));
/*  85 */     m_142416_((GuiEventListener)(this.blueSlider = new ForgeSlider(getWidth() / 2 - 100, getHeight() / 2 + 53, 202, 20, (Component)Component.m_237115_("xray.color.blue"), (Component)Component.m_237119_(), 0.0D, 255.0D, 255.0D, true)));
/*  87 */     this.oreName = new EditBox((getMinecraft()).f_91062_, getWidth() / 2 - 100, getHeight() / 2 - 70, 202, 20, (Component)Component.m_237119_());
/*  88 */     this.oreName.m_94144_(this.selectBlock.m_49954_().getString());
/*  89 */     m_142416_((GuiEventListener)this.oreName);
/*     */   }
/*     */   
/*     */   public void m_86600_() {
/*  94 */     super.m_86600_();
/*  95 */     this.oreName.m_94120_();
/*     */   }
/*     */   
/*     */   public void renderExtra(GuiGraphics graphics, int x, int y, float partialTicks) {
/* 100 */     graphics.m_280488_(this.f_96547_, this.selectBlock.m_49954_().getString(), getWidth() / 2 - 100, getHeight() / 2 - 90, 16777215);
/* 102 */     int color = 0xFF000000 | (int)this.redSlider.getValue() << 16 | (int)this.greenSlider.getValue() << 8 | (int)this.blueSlider.getValue();
/* 103 */     graphics.m_280509_(getWidth() / 2 - 100, getHeight() / 2 - 45, getWidth() / 2 + 2 + 100, getHeight() / 2 - 45 + 45, color);
/* 105 */     this.oreName.m_88315_(graphics, x, y, partialTicks);
/* 107 */     graphics.m_280480_(this.itemStack, getWidth() / 2 + 85, getHeight() / 2 - 105);
/* 108 */     graphics.m_280370_(this.f_96547_, this.itemStack, getWidth() / 2 + 85, getHeight() / 2 - 105);
/*     */   }
/*     */   
/*     */   public boolean m_6375_(double x, double y, int mouse) {
/* 117 */     if (this.oreName.m_6375_(x, y, mouse))
/* 118 */       m_7522_((GuiEventListener)this.oreName); 
/* 120 */     if (this.oreName.m_93696_() && !this.oreNameCleared) {
/* 121 */       this.oreName.m_94144_("");
/* 122 */       this.oreNameCleared = true;
/*     */     } 
/* 125 */     if (!this.oreName.m_93696_() && this.oreNameCleared && Objects.equals(this.oreName.m_94155_(), "")) {
/* 126 */       this.oreNameCleared = false;
/* 127 */       this.oreName.m_94144_(this.selectBlock.m_49954_().getString());
/*     */     } 
/* 130 */     return super.m_6375_(x, y, mouse);
/*     */   }
/*     */   
/*     */   public boolean hasTitle() {
/* 135 */     return true;
/*     */   }
/*     */   
/*     */   public String title() {
/* 140 */     return I18n.m_118938_("xray.title.config", new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\manage\GuiAddBlock.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */