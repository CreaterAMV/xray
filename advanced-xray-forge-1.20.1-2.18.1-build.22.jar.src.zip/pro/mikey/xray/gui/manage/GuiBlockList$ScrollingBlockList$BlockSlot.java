/*     */ package pro.mikey.xray.gui.manage;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import pro.mikey.xray.store.GameBlockStore;
/*     */ 
/*     */ public class BlockSlot extends AbstractSelectionList.Entry<GuiBlockList.ScrollingBlockList.BlockSlot> {
/*     */   GameBlockStore.BlockWithItemStack block;
/*     */   
/*     */   GuiBlockList.ScrollingBlockList parent;
/*     */   
/*     */   BlockSlot(GameBlockStore.BlockWithItemStack block, GuiBlockList.ScrollingBlockList parent) {
/* 127 */     this.block = block;
/* 128 */     this.parent = parent;
/*     */   }
/*     */   
/*     */   public GameBlockStore.BlockWithItemStack getBlock() {
/* 132 */     return this.block;
/*     */   }
/*     */   
/*     */   public void m_6311_(GuiGraphics graphics, int entryIdx, int top, int left, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean p_194999_5_, float partialTicks) {
/* 137 */     Font font = (GuiBlockList.ScrollingBlockList.access$000(this.parent)).f_91062_;
/* 139 */     ResourceLocation resource = ForgeRegistries.ITEMS.getKey(this.block.getItemStack().m_41720_());
/* 140 */     graphics.m_280488_(font, this.block.getItemStack().m_41720_().m_41466_().getString(), left + 35, top + 7, Color.WHITE.getRGB());
/* 141 */     graphics.m_280488_(font, (resource != null) ? resource.m_135827_() : "", left + 35, top + 17, Color.WHITE.getRGB());
/* 143 */     graphics.m_280480_(this.block.getItemStack(), left + 8, top + 7);
/* 144 */     graphics.m_280370_(font, this.block.getItemStack(), left + 8, top + 7);
/*     */   }
/*     */   
/*     */   public boolean m_6375_(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
/* 153 */     this.parent.setSelected(this);
/* 154 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\manage\GuiBlockList$ScrollingBlockList$BlockSlot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */