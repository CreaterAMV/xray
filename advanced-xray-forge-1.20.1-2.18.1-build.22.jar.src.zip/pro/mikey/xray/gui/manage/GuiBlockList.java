/*     */ package pro.mikey.xray.gui.manage;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.EditBox;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import pro.mikey.xray.ClientController;
/*     */ import pro.mikey.xray.gui.GuiSelectionScreen;
/*     */ import pro.mikey.xray.gui.utils.GuiBase;
/*     */ import pro.mikey.xray.gui.utils.ScrollingList;
/*     */ import pro.mikey.xray.store.GameBlockStore;
/*     */ 
/*     */ public class GuiBlockList extends GuiBase {
/*     */   private ScrollingBlockList blockList;
/*     */   
/*     */   private ArrayList<GameBlockStore.BlockWithItemStack> blocks;
/*     */   
/*     */   private EditBox search;
/*     */   
/*  30 */   private String lastSearched = "";
/*     */   
/*     */   public GuiBlockList() {
/*  33 */     super(false);
/*  34 */     this.blocks = ClientController.gameBlockStore.getStore();
/*     */   }
/*     */   
/*     */   public void m_7856_() {
/*  39 */     this.blockList = new ScrollingBlockList(getWidth() / 2 + 1, getHeight() / 2 - 12, 202, 185, this.blocks);
/*  40 */     m_142416_((GuiEventListener)this.blockList);
/*  42 */     this.search = new EditBox(getFontRender(), getWidth() / 2 - 100, getHeight() / 2 + 85, 140, 18, (Component)Component.m_237113_(""));
/*  43 */     this.search.m_93692_(true);
/*  44 */     m_7522_((GuiEventListener)this.search);
/*  46 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237115_("xray.single.cancel"), b -> {
/*     */             m_7379_();
/*     */             Minecraft.m_91087_().m_91152_((Screen)new GuiSelectionScreen());
/*  50 */           }).m_252794_(getWidth() / 2 + 43, getHeight() / 2 + 84)
/*  51 */         .m_253046_(60, 20)
/*  52 */         .m_253136_());
/*     */   }
/*     */   
/*     */   public void m_86600_() {
/*  57 */     this.search.m_94120_();
/*  58 */     if (!this.search.m_94155_().equals(this.lastSearched))
/*  59 */       reloadBlocks(); 
/*  61 */     super.m_86600_();
/*     */   }
/*     */   
/*     */   private void reloadBlocks() {
/*  65 */     if (this.lastSearched.equals(this.search.m_94155_()))
/*     */       return; 
/*  68 */     this.blockList.updateEntries(
/*  69 */         (this.search.m_94155_().length() == 0) ? 
/*  70 */         this.blocks : 
/*     */         
/*  73 */         (List<GameBlockStore.BlockWithItemStack>)this.blocks.stream().filter(e -> e.getItemStack().m_41786_().getString().toLowerCase().contains(this.search.m_94155_().toLowerCase())).collect(Collectors.toList()));
/*  76 */     this.lastSearched = this.search.m_94155_();
/*  77 */     this.blockList.m_93410_(0.0D);
/*     */   }
/*     */   
/*     */   public void renderExtra(GuiGraphics graphics, int x, int y, float partialTicks) {
/*  82 */     this.search.m_88315_(graphics, x, y, partialTicks);
/*  83 */     this.blockList.m_88315_(graphics, x, y, partialTicks);
/*     */   }
/*     */   
/*     */   public boolean m_6375_(double x, double y, int button) {
/*  88 */     if (this.search.m_6375_(x, y, button))
/*  89 */       m_7522_((GuiEventListener)this.search); 
/*  91 */     return super.m_6375_(x, y, button);
/*     */   }
/*     */   
/*     */   public boolean m_6050_(double p_mouseScrolled_1_, double p_mouseScrolled_3_, double p_mouseScrolled_5_) {
/*  96 */     this.blockList.m_6050_(p_mouseScrolled_1_, p_mouseScrolled_3_, p_mouseScrolled_5_);
/*  97 */     return super.m_6050_(p_mouseScrolled_1_, p_mouseScrolled_3_, p_mouseScrolled_5_);
/*     */   }
/*     */   
/*     */   static class ScrollingBlockList extends ScrollingList<ScrollingBlockList.BlockSlot> {
/*     */     static final int SLOT_HEIGHT = 35;
/*     */     
/*     */     ScrollingBlockList(int x, int y, int width, int height, List<GameBlockStore.BlockWithItemStack> blocks) {
/* 104 */       super(x, y, width, height, 35);
/* 105 */       updateEntries(blocks);
/*     */     }
/*     */     
/*     */     public void setSelected(@Nullable BlockSlot entry) {
/* 110 */       if (entry == null)
/*     */         return; 
/* 113 */       (Minecraft.m_91087_()).f_91074_.m_6915_();
/* 114 */       Minecraft.m_91087_().m_91152_((Screen)new GuiAddBlock(entry.getBlock().getBlock(), GuiBlockList::new));
/*     */     }
/*     */     
/*     */     void updateEntries(List<GameBlockStore.BlockWithItemStack> blocks) {
/* 118 */       m_93516_();
/* 119 */       blocks.forEach(block -> m_7085_(new BlockSlot(block, this)));
/*     */     }
/*     */     
/*     */     public static class BlockSlot extends AbstractSelectionList.Entry<BlockSlot> {
/*     */       GameBlockStore.BlockWithItemStack block;
/*     */       
/*     */       GuiBlockList.ScrollingBlockList parent;
/*     */       
/*     */       BlockSlot(GameBlockStore.BlockWithItemStack block, GuiBlockList.ScrollingBlockList parent) {
/* 127 */         this.block = block;
/* 128 */         this.parent = parent;
/*     */       }
/*     */       
/*     */       public GameBlockStore.BlockWithItemStack getBlock() {
/* 132 */         return this.block;
/*     */       }
/*     */       
/*     */       public void m_6311_(GuiGraphics graphics, int entryIdx, int top, int left, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean p_194999_5_, float partialTicks) {
/* 137 */         Font font = this.parent.f_93386_.f_91062_;
/* 139 */         ResourceLocation resource = ForgeRegistries.ITEMS.getKey(this.block.getItemStack().m_41720_());
/* 140 */         graphics.m_280488_(font, this.block.getItemStack().m_41720_().m_41466_().getString(), left + 35, top + 7, Color.WHITE.getRGB());
/* 141 */         graphics.m_280488_(font, (resource != null) ? resource.m_135827_() : "", left + 35, top + 17, Color.WHITE.getRGB());
/* 143 */         graphics.m_280480_(this.block.getItemStack(), left + 8, top + 7);
/* 144 */         graphics.m_280370_(font, this.block.getItemStack(), left + 8, top + 7);
/*     */       }
/*     */       
/*     */       public boolean m_6375_(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
/* 153 */         this.parent.setSelected(this);
/* 154 */         return false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BlockSlot extends AbstractSelectionList.Entry<ScrollingBlockList.BlockSlot> {
/*     */     GameBlockStore.BlockWithItemStack block;
/*     */     
/*     */     GuiBlockList.ScrollingBlockList parent;
/*     */     
/*     */     BlockSlot(GameBlockStore.BlockWithItemStack block, GuiBlockList.ScrollingBlockList parent) {
/*     */       this.block = block;
/*     */       this.parent = parent;
/*     */     }
/*     */     
/*     */     public GameBlockStore.BlockWithItemStack getBlock() {
/*     */       return this.block;
/*     */     }
/*     */     
/*     */     public void m_6311_(GuiGraphics graphics, int entryIdx, int top, int left, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean p_194999_5_, float partialTicks) {
/*     */       Font font = this.parent.f_93386_.f_91062_;
/*     */       ResourceLocation resource = ForgeRegistries.ITEMS.getKey(this.block.getItemStack().m_41720_());
/*     */       graphics.m_280488_(font, this.block.getItemStack().m_41720_().m_41466_().getString(), left + 35, top + 7, Color.WHITE.getRGB());
/*     */       graphics.m_280488_(font, (resource != null) ? resource.m_135827_() : "", left + 35, top + 17, Color.WHITE.getRGB());
/*     */       graphics.m_280480_(this.block.getItemStack(), left + 8, top + 7);
/*     */       graphics.m_280370_(font, this.block.getItemStack(), left + 8, top + 7);
/*     */     }
/*     */     
/*     */     public boolean m_6375_(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
/*     */       this.parent.setSelected(this);
/* 154 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\manage\GuiBlockList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */