/*     */ package pro.mikey.xray.gui.manage;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import pro.mikey.xray.gui.utils.ScrollingList;
/*     */ import pro.mikey.xray.store.GameBlockStore;
/*     */ 
/*     */ class ScrollingBlockList extends ScrollingList<GuiBlockList.ScrollingBlockList.BlockSlot> {
/*     */   static final int SLOT_HEIGHT = 35;
/*     */   
/*     */   ScrollingBlockList(int x, int y, int width, int height, List<GameBlockStore.BlockWithItemStack> blocks) {
/* 104 */     super(x, y, width, height, 35);
/* 105 */     updateEntries(blocks);
/*     */   }
/*     */   
/*     */   public void setSelected(@Nullable BlockSlot entry) {
/* 110 */     if (entry == null)
/*     */       return; 
/* 113 */     (Minecraft.m_91087_()).f_91074_.m_6915_();
/* 114 */     Minecraft.m_91087_().m_91152_((Screen)new GuiAddBlock(entry.getBlock().getBlock(), GuiBlockList::new));
/*     */   }
/*     */   
/*     */   void updateEntries(List<GameBlockStore.BlockWithItemStack> blocks) {
/* 118 */     m_93516_();
/* 119 */     blocks.forEach(block -> m_7085_(new BlockSlot(block, this)));
/*     */   }
/*     */   
/*     */   public static class BlockSlot extends AbstractSelectionList.Entry<BlockSlot> {
/*     */     GameBlockStore.BlockWithItemStack block;
/*     */     
/*     */     GuiBlockList.ScrollingBlockList parent;
/*     */     
/*     */     BlockSlot(GameBlockStore.BlockWithItemStack block, GuiBlockList.ScrollingBlockList parent) {
/* 127 */       this.block = block;
/* 128 */       this.parent = parent;
/*     */     }
/*     */     
/*     */     public GameBlockStore.BlockWithItemStack getBlock() {
/* 132 */       return this.block;
/*     */     }
/*     */     
/*     */     public void m_6311_(GuiGraphics graphics, int entryIdx, int top, int left, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean p_194999_5_, float partialTicks) {
/* 137 */       Font font = this.parent.f_93386_.f_91062_;
/* 139 */       ResourceLocation resource = ForgeRegistries.ITEMS.getKey(this.block.getItemStack().m_41720_());
/* 140 */       graphics.m_280488_(font, this.block.getItemStack().m_41720_().m_41466_().getString(), left + 35, top + 7, Color.WHITE.getRGB());
/* 141 */       graphics.m_280488_(font, (resource != null) ? resource.m_135827_() : "", left + 35, top + 17, Color.WHITE.getRGB());
/* 143 */       graphics.m_280480_(this.block.getItemStack(), left + 8, top + 7);
/* 144 */       graphics.m_280370_(font, this.block.getItemStack(), left + 8, top + 7);
/*     */     }
/*     */     
/*     */     public boolean m_6375_(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
/* 153 */       this.parent.setSelected(this);
/* 154 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\manage\GuiBlockList$ScrollingBlockList.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */