/*     */ package pro.mikey.xray.gui.manage;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.EditBox;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.resources.language.I18n;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraftforge.client.gui.widget.ForgeSlider;
/*     */ import org.apache.commons.lang3.tuple.Pair;
/*     */ import pro.mikey.xray.ClientController;
/*     */ import pro.mikey.xray.gui.GuiSelectionScreen;
/*     */ import pro.mikey.xray.gui.utils.GuiBase;
/*     */ import pro.mikey.xray.utils.BlockData;
/*     */ import pro.mikey.xray.xray.Controller;
/*     */ 
/*     */ public class GuiEdit extends GuiBase {
/*     */   private EditBox oreName;
/*     */   
/*     */   private ForgeSlider redSlider;
/*     */   
/*     */   private ForgeSlider greenSlider;
/*     */   
/*     */   private ForgeSlider blueSlider;
/*     */   
/*     */   private final BlockData block;
/*     */   
/*     */   public GuiEdit(BlockData block) {
/*  29 */     super(true);
/*  30 */     setSideTitle(I18n.m_118938_("xray.single.tools", new Object[0]));
/*  32 */     this.block = block;
/*     */   }
/*     */   
/*     */   public void m_7856_() {
/*  37 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237115_("xray.single.delete"), b -> {
/*     */             Controller.getBlockStore().remove(this.block.getBlockName());
/*     */             ClientController.blockStore.write(new ArrayList(Controller.getBlockStore().getStore().values()));
/*     */             m_7379_();
/*     */             getMinecraft().m_91152_((Screen)new GuiSelectionScreen());
/*  44 */           }).m_252794_(getWidth() / 2 + 78, getHeight() / 2 - 60)
/*  45 */         .m_253046_(120, 20)
/*  46 */         .m_253136_());
/*  48 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237115_("xray.single.cancel"), b -> {
/*     */             m_7379_();
/*     */             getMinecraft().m_91152_((Screen)new GuiSelectionScreen());
/*  52 */           }).m_252794_(getWidth() / 2 + 78, getHeight() / 2 + 58)
/*  53 */         .m_253046_(120, 20)
/*  54 */         .m_253136_());
/*  56 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237115_("xray.single.save"), b -> {
/*     */             BlockData block = new BlockData(this.oreName.m_94155_(), this.block.getBlockName(), ((int)this.redSlider.getValue() << 16) + ((int)this.greenSlider.getValue() << 8) + (int)this.blueSlider.getValue(), this.block.getItemStack(), this.block.isDrawing(), this.block.getOrder());
/*     */             Pair<BlockData, UUID> data = Controller.getBlockStore().getStoreByReference(block.getBlockName());
/*     */             Controller.getBlockStore().getStore().remove(data.getValue());
/*     */             Controller.getBlockStore().getStore().put((UUID)data.getValue(), block);
/*     */             ClientController.blockStore.write(new ArrayList(Controller.getBlockStore().getStore().values()));
/*     */             m_7379_();
/*     */             getMinecraft().m_91152_((Screen)new GuiSelectionScreen());
/*  74 */           }).m_252794_(getWidth() / 2 - 138, getHeight() / 2 + 83)
/*  75 */         .m_253046_(202, 20)
/*  76 */         .m_253136_());
/*  78 */     m_142416_((GuiEventListener)(this.redSlider = new ForgeSlider(getWidth() / 2 - 138, getHeight() / 2 + 7, 202, 20, (Component)Component.m_237115_("xray.color.red"), (Component)Component.m_237119_(), 0.0D, 255.0D, (this.block.getColor() >> 16 & 0xFF), true)));
/*  79 */     m_142416_((GuiEventListener)(this.greenSlider = new ForgeSlider(getWidth() / 2 - 138, getHeight() / 2 + 30, 202, 20, (Component)Component.m_237115_("xray.color.green"), (Component)Component.m_237119_(), 0.0D, 255.0D, (this.block.getColor() >> 8 & 0xFF), true)));
/*  80 */     m_142416_((GuiEventListener)(this.blueSlider = new ForgeSlider(getWidth() / 2 - 138, getHeight() / 2 + 53, 202, 20, (Component)Component.m_237115_("xray.color.blue"), (Component)Component.m_237119_(), 0.0D, 255.0D, (this.block.getColor() & 0xFF), true)));
/*  82 */     this.oreName = new EditBox((getMinecraft()).f_91062_, getWidth() / 2 - 138, getHeight() / 2 - 63, 202, 20, (Component)Component.m_237113_(""));
/*  83 */     this.oreName.m_94144_(this.block.getEntryName());
/*  84 */     m_142416_((GuiEventListener)this.oreName);
/*     */   }
/*     */   
/*     */   public void m_86600_() {
/*  89 */     super.m_86600_();
/*  90 */     this.oreName.m_94120_();
/*     */   }
/*     */   
/*     */   public void renderExtra(GuiGraphics graphics, int x, int y, float partialTicks) {
/*  95 */     graphics.m_280488_(this.f_96547_, this.block.getItemStack().m_41786_().getString(), getWidth() / 2 - 138, getHeight() / 2 - 90, 16777215);
/*  97 */     this.oreName.m_88315_(graphics, x, y, partialTicks);
/*  99 */     int color = 0xFF000000 | (int)this.redSlider.getValue() << 16 | (int)this.greenSlider.getValue() << 8 | (int)this.blueSlider.getValue();
/* 100 */     graphics.m_280509_(getWidth() / 2 - 138, getHeight() / 2 - 40, getWidth() / 2 - 36 + 100, getHeight() / 2 - 40 + 45, color);
/* 102 */     graphics.m_280480_(this.block.getItemStack(), getWidth() / 2 + 50, getHeight() / 2 - 105);
/* 103 */     graphics.m_280370_(this.f_96547_, this.block.getItemStack(), getWidth() / 2 + 50, getHeight() / 2 - 105);
/*     */   }
/*     */   
/*     */   public boolean m_6375_(double x, double y, int mouse) {
/* 112 */     if (this.oreName.m_6375_(x, y, mouse))
/* 113 */       m_7522_((GuiEventListener)this.oreName); 
/* 115 */     return super.m_6375_(x, y, mouse);
/*     */   }
/*     */   
/*     */   public boolean hasTitle() {
/* 120 */     return true;
/*     */   }
/*     */   
/*     */   public String title() {
/* 125 */     return I18n.m_118938_("xray.title.edit", new Object[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\manage\GuiEdit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */