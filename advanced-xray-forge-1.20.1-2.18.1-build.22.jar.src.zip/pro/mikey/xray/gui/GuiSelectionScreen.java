/*     */ package pro.mikey.xray.gui;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import com.mojang.blaze3d.vertex.PoseStack;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Collectors;
/*     */ import javax.annotation.Nullable;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.gui.Font;
/*     */ import net.minecraft.client.gui.GuiGraphics;
/*     */ import net.minecraft.client.gui.components.AbstractSelectionList;
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.client.gui.components.EditBox;
/*     */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*     */ import net.minecraft.client.gui.screens.Screen;
/*     */ import net.minecraft.client.player.LocalPlayer;
/*     */ import net.minecraft.client.renderer.entity.ItemRenderer;
/*     */ import net.minecraft.client.resources.language.I18n;
/*     */ import net.minecraft.locale.Language;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.network.chat.FormattedText;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.InteractionHand;
/*     */ import net.minecraft.world.entity.Entity;
/*     */ import net.minecraft.world.item.BlockItem;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.ClipContext;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraft.world.phys.BlockHitResult;
/*     */ import net.minecraft.world.phys.HitResult;
/*     */ import net.minecraft.world.phys.Vec3;
/*     */ import pro.mikey.xray.ClientController;
/*     */ import pro.mikey.xray.Configuration;
/*     */ import pro.mikey.xray.XRay;
/*     */ import pro.mikey.xray.gui.manage.GuiAddBlock;
/*     */ import pro.mikey.xray.gui.manage.GuiBlockList;
/*     */ import pro.mikey.xray.gui.manage.GuiEdit;
/*     */ import pro.mikey.xray.gui.utils.GuiBase;
/*     */ import pro.mikey.xray.gui.utils.ScrollingList;
/*     */ import pro.mikey.xray.gui.utils.SupportButton;
/*     */ import pro.mikey.xray.keybinding.KeyBindings;
/*     */ import pro.mikey.xray.store.BlockStore;
/*     */ import pro.mikey.xray.utils.BlockData;
/*     */ import pro.mikey.xray.xray.Controller;
/*     */ 
/*     */ public class GuiSelectionScreen extends GuiBase {
/*  50 */   private static final ResourceLocation CIRCLE = new ResourceLocation(XRay.PREFIX_GUI + "circle.png");
/*     */   
/*     */   private Button distButtons;
/*     */   
/*     */   private EditBox search;
/*     */   
/*     */   public ItemRenderer render;
/*     */   
/*  56 */   private String lastSearch = "";
/*     */   
/*     */   private ArrayList<BlockData> itemList;
/*     */   
/*     */   private ArrayList<BlockData> originalList;
/*     */   
/*     */   private ScrollingBlockList scrollList;
/*     */   
/*     */   public GuiSelectionScreen() {
/*  62 */     super(true);
/*  63 */     setSideTitle(I18n.m_118938_("xray.single.tools", new Object[0]));
/*  66 */     if (ClientController.blockStore.created) {
/*  67 */       List<BlockData.SerializableBlockData> blocks = ClientController.blockStore.populateDefault();
/*  68 */       Controller.getBlockStore().setStore(BlockStore.getFromSimpleBlockList(blocks));
/*  70 */       ClientController.blockStore.created = false;
/*     */     } 
/*  73 */     this.itemList = new ArrayList<>(Controller.getBlockStore().getStore().values());
/*  74 */     this.itemList.sort(Comparator.comparingInt(BlockData::getOrder));
/*  76 */     this.originalList = this.itemList;
/*     */   }
/*     */   
/*     */   public void m_7856_() {
/*  81 */     if ((getMinecraft()).f_91074_ == null)
/*     */       return; 
/*  84 */     this.render = Minecraft.m_91087_().m_91291_();
/*  85 */     m_6702_().clear();
/*  87 */     this.scrollList = new ScrollingBlockList(getWidth() / 2 - 37, getHeight() / 2 + 10, 203, 185, this.itemList, this);
/*  88 */     m_142416_((GuiEventListener)this.scrollList);
/*  90 */     this.search = new EditBox(getFontRender(), getWidth() / 2 - 137, getHeight() / 2 - 105, 202, 18, (Component)Component.m_237119_());
/*  91 */     this.search.m_94190_(true);
/*  94 */     m_142416_((GuiEventListener)new SupportButtonInner(getWidth() / 2 + 79, getHeight() / 2 - 60, 120, 20, I18n.m_118938_("xray.input.add", new Object[0]), "xray.tooltips.add_block", button -> getMinecraft().m_91152_((Screen)new GuiBlockList())));
/*  97 */     m_142416_((GuiEventListener)new SupportButtonInner(getWidth() / 2 + 79, getHeight() / 2 - 38, 120, 20, I18n.m_118938_("xray.input.add_hand", new Object[0]), "xray.tooltips.add_block_in_hand", button -> {
/*     */             ItemStack handItem = (getMinecraft()).f_91074_.m_21120_(InteractionHand.MAIN_HAND);
/*     */             if (!(handItem.m_41720_() instanceof BlockItem)) {
/*     */               (getMinecraft()).f_91074_.m_5661_((Component)Component.m_237113_("[XRay] " + I18n.m_118938_("xray.message.invalid_hand", new Object[] { handItem.m_41786_().getString() })), false);
/*     */               return;
/*     */             } 
/*     */             getMinecraft().m_91152_((Screen)new GuiAddBlock(((BlockItem)handItem.m_41720_()).m_40614_(), GuiSelectionScreen::new));
/*     */           }));
/* 108 */     m_142416_((GuiEventListener)new SupportButtonInner(getWidth() / 2 + 79, getHeight() / 2 - 16, 120, 20, I18n.m_118938_("xray.input.add_look", new Object[0]), "xray.tooltips.add_block_looking_at", button -> {
/*     */             LocalPlayer localPlayer = (getMinecraft()).f_91074_;
/*     */             if ((getMinecraft()).f_91073_ == null || localPlayer == null)
/*     */               return; 
/*     */             m_7379_();
/*     */             try {
/*     */               Vec3 look = localPlayer.m_20154_();
/*     */               Vec3 start = new Vec3(localPlayer.m_20183_().m_123341_(), (localPlayer.m_20183_().m_123342_() + localPlayer.m_20192_()), localPlayer.m_20183_().m_123343_());
/*     */               Vec3 end = new Vec3(localPlayer.m_20183_().m_123341_() + look.f_82479_ * 100.0D, (localPlayer.m_20183_().m_123342_() + localPlayer.m_20192_()) + look.f_82480_ * 100.0D, localPlayer.m_20183_().m_123343_() + look.f_82481_ * 100.0D);
/*     */               ClipContext context = new ClipContext(start, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, (Entity)localPlayer);
/*     */               BlockHitResult result = (getMinecraft()).f_91073_.m_45547_(context);
/*     */               if (result.m_6662_() == HitResult.Type.BLOCK) {
/*     */                 Block lookingAt = (getMinecraft()).f_91073_.m_8055_(result.m_82425_()).m_60734_();
/*     */                 localPlayer.m_6915_();
/*     */                 getMinecraft().m_91152_((Screen)new GuiAddBlock(lookingAt, GuiSelectionScreen::new));
/*     */               } else {
/*     */                 localPlayer.m_5661_((Component)Component.m_237113_("[XRay] " + I18n.m_118938_("xray.message.nothing_infront", new Object[0])), false);
/*     */               } 
/* 129 */             } catch (NullPointerException ex) {
/*     */               localPlayer.m_5661_((Component)Component.m_237113_("[XRay] " + I18n.m_118938_("xray.message.thats_odd", new Object[0])), false);
/*     */             } 
/*     */           }));
/* 134 */     m_142416_((GuiEventListener)(this.distButtons = (Button)new SupportButtonInner(getWidth() / 2 + 79, getHeight() / 2 + 6, 120, 20, I18n.m_118938_("xray.input.show-lava", new Object[] { Boolean.valueOf(Controller.isLavaActive()) }), "xray.tooltips.show_lava", button -> {
/*     */             Controller.toggleLava();
/*     */             button.m_93666_((Component)Component.m_237110_("xray.input.show-lava", new Object[] { Boolean.valueOf(Controller.isLavaActive()) }));
/*     */           })));
/* 139 */     m_142416_((GuiEventListener)(this.distButtons = (Button)new SupportButtonInner(getWidth() / 2 + 79, getHeight() / 2 + 36, 120, 20, I18n.m_118938_("xray.input.distance", new Object[] { Integer.valueOf(Controller.getVisualRadius()) }), "xray.tooltips.distance", button -> {
/*     */             Controller.incrementCurrentDist();
/*     */             button.m_93666_((Component)Component.m_237110_("xray.input.distance", new Object[] { Integer.valueOf(Controller.getVisualRadius()) }));
/*     */           })));
/* 143 */     m_142416_(
/* 144 */         (GuiEventListener)Button.m_253074_((Component)Component.m_237115_("xray.single.help"), button -> getMinecraft().m_91152_((Screen)new GuiHelp()))
/*     */         
/* 147 */         .m_252794_(getWidth() / 2 + 79, getHeight() / 2 + 58)
/* 148 */         .m_253046_(60, 20)
/* 149 */         .m_253136_());
/* 151 */     m_142416_(
/* 152 */         (GuiEventListener)Button.m_253074_((Component)Component.m_237115_("xray.single.close"), button -> m_7379_())
/*     */         
/* 155 */         .m_252794_(getWidth() / 2 + 79 + 62, getHeight() / 2 + 58)
/* 156 */         .m_253046_(59, 20)
/* 157 */         .m_253136_());
/*     */   }
/*     */   
/*     */   public boolean m_7933_(int keyCode, int scanCode, int modifiers) {
/* 163 */     if (!this.search.m_93696_() && keyCode == KeyBindings.toggleGui.getKey().m_84873_()) {
/* 164 */       m_7379_();
/* 165 */       return true;
/*     */     } 
/* 167 */     return super.m_7933_(keyCode, scanCode, modifiers);
/*     */   }
/*     */   
/*     */   private void updateSearch() {
/* 171 */     if (this.lastSearch.equals(this.search.m_94155_()))
/*     */       return; 
/* 174 */     if (this.search.m_94155_().isEmpty()) {
/* 175 */       this.itemList = this.originalList;
/* 176 */       this.scrollList.updateEntries(this.itemList);
/* 177 */       this.lastSearch = "";
/*     */       return;
/*     */     } 
/* 182 */     if (this.search.m_94155_().equals(":on") || this.search.m_94155_().equals(":off")) {
/* 183 */       boolean state = this.search.m_94155_().equals(":on");
/* 184 */       this
/*     */         
/* 186 */         .itemList = (ArrayList<BlockData>)this.originalList.stream().filter(e -> (e.isDrawing() == state)).collect(Collectors.toCollection(ArrayList::new));
/* 188 */       this.itemList.sort(Comparator.comparingInt(BlockData::getOrder));
/* 189 */       this.scrollList.updateEntries(this.itemList);
/* 190 */       this.lastSearch = this.search.m_94155_();
/*     */       return;
/*     */     } 
/* 194 */     this
/*     */       
/* 196 */       .itemList = (ArrayList<BlockData>)this.originalList.stream().filter(b -> b.getEntryName().toLowerCase().contains(this.search.m_94155_().toLowerCase())).collect(Collectors.toCollection(ArrayList::new));
/* 198 */     this.itemList.sort(Comparator.comparingInt(BlockData::getOrder));
/* 200 */     this.scrollList.updateEntries(this.itemList);
/* 201 */     this.lastSearch = this.search.m_94155_();
/*     */   }
/*     */   
/*     */   public void m_86600_() {
/* 206 */     super.m_86600_();
/* 208 */     if (this.search != null)
/* 209 */       this.search.m_94120_(); 
/* 212 */     updateSearch();
/*     */   }
/*     */   
/*     */   public boolean m_6375_(double x, double y, int mouse) {
/* 217 */     if (this.search.m_6375_(x, y, mouse))
/* 218 */       m_7522_((GuiEventListener)this.search); 
/* 220 */     if (mouse == 1 && this.distButtons.m_5953_(x, y)) {
/* 221 */       Controller.decrementCurrentDist();
/* 222 */       this.distButtons.m_93666_((Component)Component.m_237110_("xray.input.distance", new Object[] { Integer.valueOf(Controller.getVisualRadius()) }));
/* 223 */       this.distButtons.m_7435_(Minecraft.m_91087_().m_91106_());
/*     */     } 
/* 226 */     return super.m_6375_(x, y, mouse);
/*     */   }
/*     */   
/*     */   public void renderExtra(GuiGraphics graphics, int x, int y, float partialTicks) {
/* 231 */     this.search.m_88315_(graphics, x, y, partialTicks);
/* 232 */     this.scrollList.m_88315_(graphics, x, y, partialTicks);
/* 234 */     if (!this.search.m_93696_() && this.search.m_94155_().equals(""))
/* 235 */       graphics.m_280488_(getFontRender(), I18n.m_118938_("xray.single.search", new Object[0]), getWidth() / 2 - 130, getHeight() / 2 - 101, Color.GRAY.getRGB()); 
/*     */   }
/*     */   
/*     */   public void m_7861_() {
/* 240 */     Configuration.store.radius.save();
/* 241 */     ClientController.blockStore.write(new ArrayList(Controller.getBlockStore().getStore().values()));
/* 243 */     Controller.requestBlockFinder(true);
/* 244 */     super.m_7861_();
/*     */   }
/*     */   
/*     */   static final class SupportButtonInner extends SupportButton {
/*     */     public SupportButtonInner(int widthIn, int heightIn, int width, int height, String text, String i18nKey, Button.OnPress onPress) {
/* 249 */       super(widthIn, heightIn, width, height, (Component)Component.m_237113_(text), Component.m_237115_(i18nKey), onPress);
/*     */     }
/*     */   }
/*     */   
/*     */   static class ScrollingBlockList extends ScrollingList<ScrollingBlockList.BlockSlot> {
/*     */     static final int SLOT_HEIGHT = 35;
/*     */     
/*     */     public GuiSelectionScreen parent;
/*     */     
/*     */     ScrollingBlockList(int x, int y, int width, int height, List<BlockData> blocks, GuiSelectionScreen parent) {
/* 258 */       super(x, y, width, height, 35);
/* 259 */       updateEntries(blocks);
/* 260 */       this.parent = parent;
/*     */     }
/*     */     
/*     */     public void setSelected(@Nullable BlockSlot entry, int mouse) {
/* 264 */       if (entry == null)
/*     */         return; 
/* 267 */       if (GuiSelectionScreen.m_96638_()) {
/* 268 */         (Minecraft.m_91087_()).f_91074_.m_6915_();
/* 269 */         Minecraft.m_91087_().m_91152_((Screen)new GuiEdit(entry.block));
/*     */         return;
/*     */       } 
/* 273 */       Controller.getBlockStore().toggleDrawing(entry.block);
/* 274 */       ClientController.blockStore.write(new ArrayList(Controller.getBlockStore().getStore().values()));
/*     */     }
/*     */     
/*     */     void updateEntries(List<BlockData> blocks) {
/* 278 */       m_93516_();
/* 279 */       blocks.forEach(block -> m_7085_(new BlockSlot(block, this)));
/*     */     }
/*     */     
/*     */     public static class BlockSlot extends AbstractSelectionList.Entry<BlockSlot> {
/*     */       BlockData block;
/*     */       
/*     */       GuiSelectionScreen.ScrollingBlockList parent;
/*     */       
/*     */       BlockSlot(BlockData block, GuiSelectionScreen.ScrollingBlockList parent) {
/* 287 */         this.block = block;
/* 288 */         this.parent = parent;
/*     */       }
/*     */       
/*     */       public BlockData getBlock() {
/* 292 */         return this.block;
/*     */       }
/*     */       
/*     */       public void m_6311_(GuiGraphics guiGraphics, int entryIdx, int top, int left, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean p_194999_5_, float partialTicks) {
/* 297 */         BlockData blockData = this.block;
/* 299 */         Font font = (Minecraft.m_91087_()).f_91062_;
/* 301 */         guiGraphics.m_280488_(font, blockData.getEntryName(), left + 35, top + 7, 16777215);
/* 302 */         guiGraphics.m_280488_(font, blockData.isDrawing() ? "Enabled" : "Disabled", left + 35, top + 17, blockData.isDrawing() ? Color.GREEN.getRGB() : Color.RED.getRGB());
/* 304 */         guiGraphics.m_280480_(blockData.getItemStack(), left + 8, top + 7);
/* 305 */         guiGraphics.m_280370_(font, blockData.getItemStack(), left + 8, top + 7);
/* 312 */         if (mouseX > left && mouseX < left + entryWidth && mouseY > top && mouseY < top + entryHeight && mouseY < this.parent.getTop() + this.parent.getHeight() && mouseY > this.parent.getTop())
/* 313 */           guiGraphics.m_280245_(font, 
/*     */               
/* 315 */               Language.m_128107_().m_128112_(Arrays.asList(new FormattedText[] { (FormattedText)Component.m_237115_("xray.tooltips.edit1"), (FormattedText)Component.m_237115_("xray.tooltips.edit2") }, )), left + 15, 
/*     */               
/* 317 */               (entryIdx == this.parent.m_6702_().size() - 1) ? (top - entryHeight - 20) : (top + entryHeight + 15)); 
/* 321 */         Color color = new Color(blockData.getColor());
/* 323 */         PoseStack stack = guiGraphics.m_280168_();
/* 324 */         stack.m_85836_();
/* 325 */         RenderSystem.enableBlend();
/* 326 */         RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/* 328 */         RenderSystem.setShaderColor(0.0F, 0.0F, 0.0F, 0.5F);
/* 329 */         guiGraphics.m_280163_(GuiSelectionScreen.CIRCLE, left + entryWidth - 35, (int)(top + entryHeight / 2.0F - 9.0F), 0.0F, 0.0F, 14, 14, 14, 14);
/* 330 */         RenderSystem.setShaderColor(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, 1.0F);
/* 331 */         guiGraphics.m_280163_(GuiSelectionScreen.CIRCLE, left + entryWidth - 33, (int)(top + entryHeight / 2.0F - 7.0F), 0.0F, 0.0F, 10, 10, 10, 10);
/* 332 */         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 333 */         RenderSystem.disableBlend();
/* 334 */         stack.m_85849_();
/*     */       }
/*     */       
/*     */       public boolean m_6375_(double p_mouseClicked_1_, double p_mouseClicked_3_, int mouse) {
/* 339 */         this.parent.setSelected(this, mouse);
/* 340 */         return false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BlockSlot extends AbstractSelectionList.Entry<ScrollingBlockList.BlockSlot> {
/*     */     BlockData block;
/*     */     
/*     */     GuiSelectionScreen.ScrollingBlockList parent;
/*     */     
/*     */     BlockSlot(BlockData block, GuiSelectionScreen.ScrollingBlockList parent) {
/*     */       this.block = block;
/*     */       this.parent = parent;
/*     */     }
/*     */     
/*     */     public BlockData getBlock() {
/*     */       return this.block;
/*     */     }
/*     */     
/*     */     public void m_6311_(GuiGraphics guiGraphics, int entryIdx, int top, int left, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean p_194999_5_, float partialTicks) {
/*     */       BlockData blockData = this.block;
/*     */       Font font = (Minecraft.m_91087_()).f_91062_;
/*     */       guiGraphics.m_280488_(font, blockData.getEntryName(), left + 35, top + 7, 16777215);
/*     */       guiGraphics.m_280488_(font, blockData.isDrawing() ? "Enabled" : "Disabled", left + 35, top + 17, blockData.isDrawing() ? Color.GREEN.getRGB() : Color.RED.getRGB());
/*     */       guiGraphics.m_280480_(blockData.getItemStack(), left + 8, top + 7);
/*     */       guiGraphics.m_280370_(font, blockData.getItemStack(), left + 8, top + 7);
/*     */       if (mouseX > left && mouseX < left + entryWidth && mouseY > top && mouseY < top + entryHeight && mouseY < this.parent.getTop() + this.parent.getHeight() && mouseY > this.parent.getTop())
/*     */         guiGraphics.m_280245_(font, Language.m_128107_().m_128112_(Arrays.asList(new FormattedText[] { (FormattedText)Component.m_237115_("xray.tooltips.edit1"), (FormattedText)Component.m_237115_("xray.tooltips.edit2") }, )), left + 15, (entryIdx == this.parent.m_6702_().size() - 1) ? (top - entryHeight - 20) : (top + entryHeight + 15)); 
/*     */       Color color = new Color(blockData.getColor());
/*     */       PoseStack stack = guiGraphics.m_280168_();
/*     */       stack.m_85836_();
/*     */       RenderSystem.enableBlend();
/*     */       RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*     */       RenderSystem.setShaderColor(0.0F, 0.0F, 0.0F, 0.5F);
/*     */       guiGraphics.m_280163_(GuiSelectionScreen.CIRCLE, left + entryWidth - 35, (int)(top + entryHeight / 2.0F - 9.0F), 0.0F, 0.0F, 14, 14, 14, 14);
/*     */       RenderSystem.setShaderColor(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, 1.0F);
/*     */       guiGraphics.m_280163_(GuiSelectionScreen.CIRCLE, left + entryWidth - 33, (int)(top + entryHeight / 2.0F - 7.0F), 0.0F, 0.0F, 10, 10, 10, 10);
/*     */       RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/*     */       RenderSystem.disableBlend();
/*     */       stack.m_85849_();
/*     */     }
/*     */     
/*     */     public boolean m_6375_(double p_mouseClicked_1_, double p_mouseClicked_3_, int mouse) {
/*     */       this.parent.setSelected(this, mouse);
/* 340 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\GuiSelectionScreen.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */