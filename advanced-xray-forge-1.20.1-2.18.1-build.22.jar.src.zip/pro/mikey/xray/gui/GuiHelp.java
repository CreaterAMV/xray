/*    */ package pro.mikey.xray.gui;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.GuiGraphics;
/*    */ import net.minecraft.client.gui.components.Button;
/*    */ import net.minecraft.client.gui.components.events.GuiEventListener;
/*    */ import net.minecraft.client.gui.screens.Screen;
/*    */ import net.minecraft.client.resources.language.I18n;
/*    */ import net.minecraft.network.chat.Component;
/*    */ import net.minecraft.resources.ResourceLocation;
/*    */ import pro.mikey.xray.gui.utils.GuiBase;
/*    */ 
/*    */ public class GuiHelp extends GuiBase {
/*    */   private List<LinedText> areas;
/*    */   
/*    */   public GuiHelp() {
/* 18 */     super(false);
/* 22 */     this.areas = new ArrayList<>();
/*    */     setSize(380, 210);
/*    */   }
/*    */   
/*    */   public void m_7856_() {
/* 26 */     super.m_7856_();
/* 28 */     this.areas.clear();
/* 29 */     this.areas.add(new LinedText("xray.message.help.gui"));
/* 30 */     this.areas.add(new LinedText("xray.message.help.warning"));
/* 32 */     m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237115_("xray.single.close"), btn -> {
/*    */             m_7379_();
/*    */             Minecraft.m_91087_().m_91152_((Screen)new GuiSelectionScreen());
/* 36 */           }).m_252794_(getWidth() / 2 - 100, getHeight() / 2 + 80)
/* 37 */         .m_253046_(200, 20)
/* 38 */         .m_253136_());
/*    */   }
/*    */   
/*    */   public void renderExtra(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
/* 44 */     int lineY = getHeight() / 2 - 85;
/* 45 */     for (LinedText linedText : this.areas) {
/* 46 */       for (String line : linedText.getLines()) {
/* 47 */         lineY += 12;
/* 48 */         guiGraphics.m_280488_(getFontRender(), line, getWidth() / 2 - 176, lineY, Color.WHITE.getRGB());
/*    */       } 
/* 50 */       lineY += 10;
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean hasTitle() {
/* 56 */     return true;
/*    */   }
/*    */   
/*    */   public ResourceLocation getBackground() {
/* 61 */     return BG_LARGE;
/*    */   }
/*    */   
/*    */   public String title() {
/* 66 */     return I18n.m_118938_("xray.single.help", new Object[0]);
/*    */   }
/*    */   
/*    */   private static class LinedText {
/*    */     private String[] lines;
/*    */     
/*    */     LinedText(String key) {
/* 73 */       this.lines = I18n.m_118938_(key, new Object[0]).split("\\R");
/*    */     }
/*    */     
/*    */     String[] getLines() {
/* 77 */       return this.lines;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\GuiHelp.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */