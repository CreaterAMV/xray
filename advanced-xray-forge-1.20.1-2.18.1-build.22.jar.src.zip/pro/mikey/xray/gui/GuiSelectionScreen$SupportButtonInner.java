/*     */ package pro.mikey.xray.gui;
/*     */ 
/*     */ import net.minecraft.client.gui.components.Button;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import pro.mikey.xray.gui.utils.SupportButton;
/*     */ 
/*     */ final class SupportButtonInner extends SupportButton {
/*     */   public SupportButtonInner(int widthIn, int heightIn, int width, int height, String text, String i18nKey, Button.OnPress onPress) {
/* 249 */     super(widthIn, heightIn, width, height, (Component)Component.m_237113_(text), Component.m_237115_(i18nKey), onPress);
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\gui\GuiSelectionScreen$SupportButtonInner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */