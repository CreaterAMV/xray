/*     */ package pro.mikey.xray.store;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Random;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.network.chat.Component;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraftforge.common.Tags;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import net.minecraftforge.registries.tags.ITagManager;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.LogManager;
/*     */ import org.apache.logging.log4j.Logger;
/*     */ import pro.mikey.xray.XRay;
/*     */ import pro.mikey.xray.utils.BlockData;
/*     */ 
/*     */ public class DiscoveryStorage {
/*  29 */   private static final Logger LOGGER = LogManager.getLogger();
/*     */   
/*  31 */   private static final Path STORE_FILE = (Minecraft.m_91087_()).f_91069_.toPath().resolve(String.format("config/%s/block_store.json", new Object[] { "xray" }));
/*     */   
/*  33 */   private static final Random RANDOM = new Random();
/*     */   
/*  34 */   private static final Gson PRETTY_JSON = (new GsonBuilder()).setPrettyPrinting().create();
/*     */   
/*     */   public boolean created = false;
/*     */   
/*     */   public DiscoveryStorage() {
/*  40 */     if (Files.exists(STORE_FILE, new java.nio.file.LinkOption[0]))
/*     */       return; 
/*  44 */     boolean createdPath = STORE_FILE.getParent().toFile().mkdirs();
/*  45 */     if (!createdPath) {
/*  46 */       LOGGER.error("Failed to create dirs for {}", STORE_FILE);
/*     */       return;
/*     */     } 
/*  50 */     this.created = true;
/*  53 */     write(new ArrayList<>());
/*  54 */     LOGGER.info("Created block store");
/*     */   }
/*     */   
/*     */   public void write(ArrayList<BlockData> blockData) {
/*  58 */     List<BlockData.SerializableBlockData> simpleBlockData = new ArrayList<>();
/*  59 */     blockData.forEach(e -> simpleBlockData.add(new BlockData.SerializableBlockData(e.getEntryName(), e.getBlockName(), e.getColor(), e.isDrawing(), e.getOrder())));
/*  61 */     write(simpleBlockData);
/*     */   }
/*     */   
/*     */   private void write(List<BlockData.SerializableBlockData> simpleBlockData) {
/*     */     try {
/*  65 */       BufferedWriter writer = new BufferedWriter(new FileWriter(STORE_FILE.toFile()));
/*     */       try {
/*  66 */         PRETTY_JSON.toJson(simpleBlockData, writer);
/*  67 */         writer.close();
/*     */       } catch (Throwable throwable) {
/*     */         try {
/*     */           writer.close();
/*     */         } catch (Throwable throwable1) {
/*     */           throwable.addSuppressed(throwable1);
/*     */         } 
/*     */         throw throwable;
/*     */       } 
/*  67 */     } catch (IOException e) {
/*  68 */       LOGGER.error("Failed to write json data to {}", STORE_FILE);
/*     */     } 
/*     */   }
/*     */   
/*     */   public List<BlockData.SerializableBlockData> read() {
/*  73 */     if (!Files.exists(STORE_FILE, new java.nio.file.LinkOption[0]))
/*  74 */       return new ArrayList<>(); 
/*     */     try {
/*  78 */       Type type = (new TypeToken<List<BlockData.SerializableBlockData>>() {
/*     */         
/*  78 */         }).getType();
/*     */       try {
/*  79 */         BufferedReader reader = new BufferedReader(new FileReader(STORE_FILE.toFile()));
/*     */         try {
/*  80 */           List<BlockData.SerializableBlockData> list = (List)PRETTY_JSON.fromJson(reader, type);
/*  81 */           reader.close();
/*     */           return list;
/*     */         } catch (Throwable throwable) {
/*     */           try {
/*     */             reader.close();
/*     */           } catch (Throwable throwable1) {
/*     */             throwable.addSuppressed(throwable1);
/*     */           } 
/*     */           throw throwable;
/*     */         } 
/*  81 */       } catch (JsonSyntaxException ex) {
/*  82 */         XRay.logger.log(Level.ERROR, "Failed to read json data from " + STORE_FILE);
/*     */       } 
/*  84 */     } catch (IOException e) {
/*  85 */       XRay.logger.log(Level.ERROR, "Failed to read json data from " + STORE_FILE);
/*     */     } 
/*  88 */     return new ArrayList<>();
/*     */   }
/*     */   
/*     */   public List<BlockData.SerializableBlockData> populateDefault() {
/*  97 */     List<BlockData.SerializableBlockData> oresData = new ArrayList<>();
/* 100 */     ITagManager<Block> blockTags = ForgeRegistries.BLOCKS.tags();
/* 101 */     if (blockTags == null)
/* 102 */       return List.of(); 
/* 105 */     int orderTrack = 0;
/* 106 */     for (Block block : blockTags.getTag(Tags.Blocks.ORES))
/* 107 */       oresData.add(new BlockData.SerializableBlockData(Component.m_237115_(block.m_7705_()).getString(), (
/* 108 */             (ResourceLocation)Objects.<ResourceLocation>requireNonNull(ForgeRegistries.BLOCKS.getKey(block))).toString(), (RANDOM
/* 109 */             .nextInt(255) << 16) + (RANDOM.nextInt(255) << 8) + RANDOM.nextInt(255), false, orderTrack++)); 
/* 115 */     LOGGER.info("Setting up default ores to the render list");
/* 116 */     write(oresData);
/* 117 */     return oresData;
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\store\DiscoveryStorage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */