package pro.mikey.xray.store;

import com.google.gson.reflect.TypeToken;
import java.util.List;
import pro.mikey.xray.utils.BlockData;

class null extends TypeToken<List<BlockData.SerializableBlockData>> {}


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\store\DiscoveryStorage$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */