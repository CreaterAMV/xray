/*    */ package pro.mikey.xray.store;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.world.item.Item;
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraft.world.item.Items;
/*    */ import net.minecraft.world.level.ItemLike;
/*    */ import net.minecraft.world.level.block.Block;
/*    */ import net.minecraft.world.level.block.Blocks;
/*    */ import net.minecraftforge.registries.ForgeRegistries;
/*    */ import pro.mikey.xray.xray.Controller;
/*    */ 
/*    */ public class GameBlockStore {
/* 15 */   private ArrayList<BlockWithItemStack> store = new ArrayList<>();
/*    */   
/*    */   public void populate() {
/* 25 */     if (this.store.size() != 0)
/*    */       return; 
/* 28 */     for (Item item : ForgeRegistries.ITEMS) {
/* 29 */       if (!(item instanceof net.minecraft.world.item.BlockItem))
/*    */         continue; 
/* 32 */       Block block = Block.m_49814_(item);
/* 33 */       if (item == Items.f_41852_ || block == Blocks.f_50016_ || Controller.blackList.contains(block))
/*    */         continue; 
/* 36 */       this.store.add(new BlockWithItemStack(block, new ItemStack((ItemLike)item)));
/*    */     } 
/*    */   }
/*    */   
/*    */   public void repopulate() {
/* 42 */     this.store.clear();
/* 43 */     populate();
/*    */   }
/*    */   
/*    */   public ArrayList<BlockWithItemStack> getStore() {
/* 47 */     return this.store;
/*    */   }
/*    */   
/*    */   public static final class BlockWithItemStack {
/*    */     private Block block;
/*    */     
/*    */     private ItemStack itemStack;
/*    */     
/*    */     public BlockWithItemStack(Block block, ItemStack itemStack) {
/* 55 */       this.block = block;
/* 56 */       this.itemStack = itemStack;
/*    */     }
/*    */     
/*    */     public Block getBlock() {
/* 60 */       return this.block;
/*    */     }
/*    */     
/*    */     public ItemStack getItemStack() {
/* 64 */       return this.itemStack;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\store\GameBlockStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */