/*    */ package pro.mikey.xray.store;
/*    */ 
/*    */ import net.minecraft.world.item.ItemStack;
/*    */ import net.minecraft.world.level.block.Block;
/*    */ 
/*    */ public final class BlockWithItemStack {
/*    */   private Block block;
/*    */   
/*    */   private ItemStack itemStack;
/*    */   
/*    */   public BlockWithItemStack(Block block, ItemStack itemStack) {
/* 55 */     this.block = block;
/* 56 */     this.itemStack = itemStack;
/*    */   }
/*    */   
/*    */   public Block getBlock() {
/* 60 */     return this.block;
/*    */   }
/*    */   
/*    */   public ItemStack getItemStack() {
/* 64 */     return this.itemStack;
/*    */   }
/*    */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\store\GameBlockStore$BlockWithItemStack.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */