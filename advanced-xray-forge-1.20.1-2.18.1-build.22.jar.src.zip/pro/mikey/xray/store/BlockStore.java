/*     */ package pro.mikey.xray.store;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.resources.ResourceLocation;
/*     */ import net.minecraft.world.item.ItemStack;
/*     */ import net.minecraft.world.level.ItemLike;
/*     */ import net.minecraft.world.level.block.Block;
/*     */ import net.minecraftforge.registries.ForgeRegistries;
/*     */ import org.apache.commons.lang3.tuple.ImmutablePair;
/*     */ import org.apache.commons.lang3.tuple.Pair;
/*     */ import pro.mikey.xray.utils.BlockData;
/*     */ 
/*     */ public class BlockStore {
/*  15 */   private HashMap<UUID, BlockData> store = new HashMap<>();
/*     */   
/*  16 */   private HashMap<String, UUID> storeReference = new HashMap<>();
/*     */   
/*     */   public void put(BlockData data) {
/*  19 */     if (this.storeReference.containsKey(data.getBlockName()))
/*     */       return; 
/*  22 */     UUID uniqueId = UUID.randomUUID();
/*  23 */     this.store.put(uniqueId, data);
/*  24 */     this.storeReference.put(data.getBlockName(), uniqueId);
/*     */   }
/*     */   
/*     */   public void remove(String blockRegistry) {
/*  28 */     if (!this.storeReference.containsKey(blockRegistry))
/*     */       return; 
/*  31 */     UUID uuid = this.storeReference.get(blockRegistry);
/*  32 */     this.storeReference.remove(blockRegistry);
/*  33 */     this.store.remove(uuid);
/*     */   }
/*     */   
/*     */   public HashMap<UUID, BlockData> getStore() {
/*  37 */     return this.store;
/*     */   }
/*     */   
/*     */   public void setStore(ArrayList<BlockData> store) {
/*  41 */     this.store.clear();
/*  42 */     this.storeReference.clear();
/*  44 */     store.forEach(this::put);
/*     */   }
/*     */   
/*     */   public Pair<BlockData, UUID> getStoreByReference(String name) {
/*  48 */     UUID uniqueId = this.storeReference.get(name);
/*  49 */     if (uniqueId == null)
/*  50 */       return null; 
/*  52 */     BlockData blockData = this.store.get(uniqueId);
/*  53 */     if (blockData == null)
/*  54 */       return null; 
/*  56 */     return (Pair<BlockData, UUID>)new ImmutablePair(blockData, uniqueId);
/*     */   }
/*     */   
/*     */   public void toggleDrawing(BlockData data) {
/*  60 */     UUID uniqueId = this.storeReference.get(data.getBlockName());
/*  61 */     if (uniqueId == null)
/*     */       return; 
/*  65 */     BlockData blockData = this.store.get(uniqueId);
/*  66 */     if (blockData == null)
/*     */       return; 
/*  69 */     blockData.setDrawing(!blockData.isDrawing());
/*     */   }
/*     */   
/*     */   public static ArrayList<BlockData> getFromSimpleBlockList(List<BlockData.SerializableBlockData> simpleList) {
/*  74 */     ArrayList<BlockData> blockData = new ArrayList<>();
/*  76 */     for (BlockData.SerializableBlockData e : simpleList) {
/*  77 */       if (e == null)
/*     */         continue; 
/*  80 */       ResourceLocation location = null;
/*     */       try {
/*  82 */         location = new ResourceLocation(e.getBlockName());
/*  83 */       } catch (Exception exception) {}
/*  84 */       if (location == null)
/*     */         continue; 
/*  87 */       Block block = (Block)ForgeRegistries.BLOCKS.getValue(location);
/*  88 */       if (block == null)
/*     */         continue; 
/*  91 */       blockData.add(new BlockData(e
/*     */             
/*  93 */             .getName(), e
/*  94 */             .getBlockName(), e
/*  95 */             .getColor(), new ItemStack((ItemLike)block, 1), e
/*     */             
/*  97 */             .isDrawing(), e
/*  98 */             .getOrder()));
/*     */     } 
/* 103 */     return blockData;
/*     */   }
/*     */ }


/* Location:              C:\Users\Artem\Downloads\advanced-xray-forge-1.20.1-2.18.1-build.22.jar!\pro\mikey\xray\store\BlockStore.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */